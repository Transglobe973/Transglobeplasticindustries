export default function About() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>About Us</h1>
      <p>Transglobe Industries is dedicated to providing high-quality plastic solutions tailored to your business needs.</p>
    </div>
  );
}