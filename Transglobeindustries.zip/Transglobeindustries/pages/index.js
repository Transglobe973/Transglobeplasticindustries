export default function Home() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Welcome to Transglobe Industries</h1>
      <p>Your trusted partner in quality plastic products.</p>
    </div>
  );
}