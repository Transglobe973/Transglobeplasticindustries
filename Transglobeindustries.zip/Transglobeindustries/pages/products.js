export default function Products() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Our Products</h1>
      <ul>
        <li>Plastic Bottles</li>
        <li>Food Containers</li>
        <li>Custom Packaging</li>
      </ul>
    </div>
  );
}