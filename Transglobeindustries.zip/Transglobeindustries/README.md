# Transglobe Industries Website

Basic Next.js starter for your plastic business.  
Pages: Home, Products, About Us, Contact Us.  
Build on top of this as you scale!